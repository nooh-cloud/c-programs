#include<stdio.h>
int main(){
    int num;
    //ask the user to enter the number
    printf("Enter a Number:");
    scanf("%d",&num);
    //check if the number is odd or even
    if(num %2==0){
        printf("%d is an even number");
    }
    else{
        printf("%d is an odd number");
    }
    return 0;
}