#include <stdio.h>
int main()
{
    int i;
    int mynumber[] ={3,4,5,6};
    int le=sizeof(mynumber)/sizeof(mynumber[0]);
    // int a=sizeof(mynumber);
    // printf("%d\n",a);
    // int b=sizeof(mynumber[0]);
    // printf("%d\n",b);
    // int le=a/b;
    printf("%d",le);
    return 0;
}
