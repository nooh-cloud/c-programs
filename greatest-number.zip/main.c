#include <stdio.h>

int main()
{
    int num1;int num2;
    printf("enter two numbers:");
    scanf("%d%d",&num1,&num2);
    
    if(num1>num2){
        printf("the greater number is:%d",num1);
    }
    else
        printf("the greater number is:%d",num2);
    return 0;
}
