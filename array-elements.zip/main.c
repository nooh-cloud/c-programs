#include <stdio.h>

int main()
{
    int n;
/*int i; global variable*/
     printf("enter the number of elements: ");
     scanf("%d",&n);
     int arr[n];
        for(int i=0;i<n;i++){
       scanf("%d",&arr[i]);
      }
      printf("\nthe number of elements are:");
      for(int i=0;i<n;i++){
          printf("%d ",arr[i]);
     }
    
 

        return 0;
}
