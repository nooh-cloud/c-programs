#include<stdio.h>
int main(){
    
    int n;
    printf("enter the number of elements:");
    scanf("%d",&n);
    
    int mynumber[n];
    printf("enter the elements:");
    
    for(int i=0;i<n;i++){
        scanf("%d",&mynumber[i]);
    }

    for(int i=0;i<n;i++){
        printf("%d",mynumber[i]);
    }
    return 0;
}