/*#include<stdio.h>
int main() {
    for (int i=1;i<=10;i++) {
        printf(" %d",i);           //for loop
    }
    return 0;
} */


/*#include<stdio.h>
int main(){
    int i=1;
    while(i<=10){
        printf(" %d",i);        //while loop
        i++;
    }
     return 0;
} */


#include<stdio.h>
int main(){
    int i=1;
    do {
        printf(" %d",i);        //do while loop
        i++;
        } while(i <= 10);
        return 0;
        
    }
   
