#include <stdio.h>

int main()
{
    int i,j,limit,temp;
    printf("enter an array");
    scanf("%d",&limit);
    
    int my_array[limit];                 
    
    printf("enter the numbers:");
    for(i=0;i<limit;i++){
    scanf("%d",&my_array[i]);
    }
    
    for(i=0;i<limit;i++){
        
        for(j=i+1;j<limit;j++){
            
            if(my_array[i]>my_array[j])
            {
                
                temp=my_array[i];
                my_array[i]=my_array[j];
                my_array[j]=temp;
            }
        }
    }
    
    printf("sorted array:\n");
    for(i=0;i<limit;i++){
        printf("%d",my_array[i]);
    }
    
    return 0;
}
