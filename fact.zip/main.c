#include <stdio.h>

int main()
{
    int i;
    int n,sum=0;
    printf("enter an integer");
    scanf("%d",&n);
    
    for(int i=1;i<=n;i++){
        sum+=i;
        
    }
    printf("the factorial is:%d",sum);
    return 0;
}
