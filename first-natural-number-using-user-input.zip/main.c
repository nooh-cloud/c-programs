#include <stdio.h>

int main()
{
    int i,n,sum = 0;
    printf("enter a number from 21 to 30: ");
    scanf("%d",&n);
    for(i=21;i<=n;++i){
    printf("%d ",i);
    sum += i;
}
    printf("\n the sum of first %d natural number:  %d\n", n, sum);

    return 0;
}