#include<stdio.h>
int main(){
    char str[]="GDB ONLINE";
    printf("%s",str);
}
